export declare class ProductService {
    getTest(): string;
}
