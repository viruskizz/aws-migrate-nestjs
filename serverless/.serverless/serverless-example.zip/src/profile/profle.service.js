"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ProfileService = void 0;
var common_1 = require("@nestjs/common");
var ProfileService = exports.ProfileService = (function () {
    function ProfileService() {
        this.data = [
            {
                id: 1,
                firstname: 'Araiva',
                lastname: 'Viruskizz',
            },
            {
                id: 2,
                firstname: 'Thitiwut',
                lastname: 'Somsa',
            },
        ];
    }
    ProfileService.prototype.getAll = function () {
        return this.data;
    };
    ProfileService.prototype.getOne = function (id) {
        return this.data.find(function (e) { return e.id === id; });
    };
    ProfileService.prototype.getTest = function () {
        return 'Hello Profile!';
    };
    ProfileService = __decorate([
        (0, common_1.Injectable)()
    ], ProfileService);
    return ProfileService;
}());
//# sourceMappingURL=profle.service.js.map