import { ProfileService } from './profle.service';
export declare class ProfileController {
    private readonly profileService;
    constructor(profileService: ProfileService);
    getTest(): string;
    getAll(): any[];
}
