import { ProfileService } from './profle.service';
import { Profile } from './profile.interface';
export declare class ProfileController {
    private readonly profileService;
    constructor(profileService: ProfileService);
    getTest(): string;
    getProfile(id: number): Profile | any;
    getAll(): any[];
}
