export interface Profile {
    id: number;
    firstname: string;
    lastname: string;
}
