import { Profile } from './profile.interface';
export declare class ProfileService {
    private readonly data;
    getAll(): Profile[];
    getOne(id: number): Profile | undefined;
    getTest(): string;
}
