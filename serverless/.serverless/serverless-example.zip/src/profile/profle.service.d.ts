import { Profile } from './profile.interface';
export declare class ProfileService {
    private readonly data;
    getAll(): Profile[];
    get(id: number): void;
    getTest(): string;
}
